import { createContext } from "react";

const CatContext = createContext();

export default CatContext;