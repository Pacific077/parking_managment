import mongoose from "mongoose";
import { RegisterTrafficPoint } from "./TrafficController";


